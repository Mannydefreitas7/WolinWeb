<header class="header">
    <div class="container flex center_alone">
        <?php include get_template_directory().  '/inc/components/logo.php'; ?>
    </div>
    <div class="flex center_cta"> 
        <?php include get_template_directory().  '/inc/components/nav.php'; ?>
    </div>
</header>