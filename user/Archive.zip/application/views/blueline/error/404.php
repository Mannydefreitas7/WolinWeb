<div class="col-sm-13  col-md-12 main">  
    <div class="row">
	<div style="text-align:center; margin:100px 0">
		<h1 style="font-size:80px">404 Error</h1>
		<h2 style="margin:20px 0; color:#666;">The Page you requested does not exist!</h2>
	</div>
	</div>
</div>		