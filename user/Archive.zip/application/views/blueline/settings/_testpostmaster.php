
        <pre><?php print_r($trace); ?></pre>
<div class="alert alert-<?=$msgresult;?>"><?=$result;?></div>

        <div class="modal-footer">
        <a class="btn" data-dismiss="modal"><?=$this->lang->line('application_close');?></a>
        </div>


