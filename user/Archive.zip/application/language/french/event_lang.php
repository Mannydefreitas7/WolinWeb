<?php
$lang['event_invoice_overdue'] = 'Le paiement de la facture {invoice_number} est <span class="label label-important">en retard </span>';
$lang['event_project_overdue'] = '<span class="label label-important">Date limite</span> du projet {project_number} atteinte';
$lang['event_subscription_new_invoice'] = '<span class="label label-warning">Nouvelle facture</span> nécessaire pour l\'abonnement {subscription_number}';

