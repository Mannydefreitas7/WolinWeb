<?php
$lang['event_invoice_overdue'] = '{invoice_number} numaralı fatura <span class="label label-important"> tarihi geçmiş durumdadır.</span>';
$lang['event_project_overdue'] = '{project_number} numaralı proje <span class="label label-important">son süresine ulaşmıştır.</span>';
$lang['event_subscription_new_invoice'] = '<span class="label label-warning">Yeni fatura</span> abonelik için gereklidir. {subscription_number}';

