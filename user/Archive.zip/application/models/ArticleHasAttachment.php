<?php

class ArticleHasAttachment extends ActiveRecord\Model {
    static $table_name = 'article_has_attachments';

    
}
