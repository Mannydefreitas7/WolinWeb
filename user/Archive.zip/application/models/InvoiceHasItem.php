<?php

class InvoiceHasItem extends ActiveRecord\Model {
    static $table_name = 'invoice_has_items';
  
}
